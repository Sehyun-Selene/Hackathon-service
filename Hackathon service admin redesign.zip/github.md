repo: Sehyun-Selene/Hackathon-service
branch: main
path: admin-app

## Last sync
date: 2026-09-10T05:27:04Z

### Updated in this project
- Read admin app source (App.jsx, CallsTab, OrdersTab, CoachStatusTab) as design context
- Copied Pretendard Variable font + 52g logo into the project
- Lifted the app's CSS tokens (violet #6d5ae6, #e9ebf0/#fff/#1a1d24/#e1e4ea, green/amber/red) into the redesign
- Built `Admin Redesign.dc.html` — 3 call-card layouts, 3 drawer-nav structures, mate-status screen

## Screen map
| Screen | Built from |
| --- | --- |
| 호출 알림 (1a/1b/1c) | admin-app/src/components/CallsTab.jsx, admin-app/src/App.jsx |
| 드로어 내비 (1d/1e/1f) | admin-app/src/App.jsx (TAB_DEFS, .side-nav) |
| 마스터 메이트 현황 (1g) | admin-app/src/components/CoachStatusTab.jsx |
